package org.armedbear.lisp.protocol;

/** Mark implementation of the LispObject protocol. */
public interface LispObject {
    public org.armedbear.lisp.LispObject typeOf();
    // TODO fill in with other functions as need arises
}

