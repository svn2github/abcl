/*
 * room.java
 *
 * Copyright (C) 2003-2005 Peter Graves
 * $Id: room.java 12019 2009-06-20 18:38:43Z ehuelsmann $
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * As a special exception, the copyright holders of this library give you
 * permission to link this library with independent modules to produce an
 * executable, regardless of the license terms of these independent
 * modules, and to copy and distribute the resulting executable under
 * terms of your choice, provided that you also meet, for each linked
 * independent module, the terms and conditions of the license of that
 * module.  An independent module is a module which is not derived from
 * or based on this library.  If you modify this library, you may extend
 * this exception to your version of the library, but you are not
 * obligated to do so.  If you do not wish to do so, delete this
 * exception statement from your version.
 */

package org.armedbear.lisp;

// ### room
public final class room extends Primitive
{
    private room()
    {
        super("room", "&optional x");
    }

    @Override
    public LispObject execute(LispObject[] args) throws ConditionThrowable
    {
        if (args.length > 1)
            return error(new WrongNumberOfArgumentsException(this));
        Runtime runtime = Runtime.getRuntime();
        long total = runtime.totalMemory();
        long free = runtime.freeMemory();

        long used = total - free;
        Stream out = getStandardOutput();
        StringBuffer sb = new StringBuffer("Total memory ");
        sb.append(total);
        sb.append(" bytes");
        sb.append(System.getProperty("line.separator"));
        sb.append(used);
        sb.append(" bytes used");
        sb.append(System.getProperty("line.separator"));
        sb.append(free);
        sb.append(" bytes free");
        sb.append(System.getProperty("line.separator"));
        out._writeString(sb.toString());
        out._finishOutput();
        return LispThread.currentThread().setValues(number(used),
                number(total),number(runtime.maxMemory()));
    }

    private static final Primitive ROOM = new room();
}
